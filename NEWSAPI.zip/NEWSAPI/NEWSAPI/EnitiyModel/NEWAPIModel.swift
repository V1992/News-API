//
//  NEWAPIModel.swift
//  NEWSAPI
//
//  Created by VARADA on 06/10/21.
//

import Foundation
import UIKit

struct NewsAPIEntityModel {
    let author: String?
    let desc: String?
    let title: String?
    let image:NSData
}
