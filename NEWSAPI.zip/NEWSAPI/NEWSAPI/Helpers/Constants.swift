//
//  Constants.swift
//  NEWSAPI
//
//  Created by VARADA on 06/10/21.
//

import Foundation

struct EndPoint{
    static let baseUrl = "https://newsapi.org/"
    static let infoUrl = "v2/everything"
}
struct Credentials{
    static let APIKEY = "fda25d4bcd0949dbb4a45930944c9182"
}
struct Entity{
    static let name = "NEWSAPI"
}

