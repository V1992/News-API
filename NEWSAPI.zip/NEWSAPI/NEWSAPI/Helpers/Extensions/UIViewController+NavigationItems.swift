//
//  UIViewController+NavigationItems.swift
//  NEWSAPI
//
//  Created by VARADA on 06/10/21.
//

import UIKit
import CoreData

extension UIViewController {
    var appDelegate:AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }
    var uiApplication : UIApplication {
        return UIApplication.shared
    }
    var context:NSManagedObjectContext{
        return appDelegate.persistentContainer.viewContext
    }
}
