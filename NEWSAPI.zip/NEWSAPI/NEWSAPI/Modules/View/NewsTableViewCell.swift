//
//  NewsTableViewCell.swift
//  NEWSAPI
//
//  Created by VARADA on 06/10/21.
//

import UIKit

class NewsTableViewCell: UITableViewCell {

    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var newsImageView: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var descriptionLbl: UILabel!
    @IBOutlet weak var authorLbl: UILabel!

    @IBOutlet weak var imgHeightContraint: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        setUIView()
    }

    func setUIView(){
        bgView.layer.cornerRadius = 10.0
        newsImageView.layer.cornerRadius = 10.0
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

    func configureCell(_ data : Article){
        titleLbl.text = data.title
        descriptionLbl.text = data.articleDescription
        authorLbl.text = data.author
    }
}
