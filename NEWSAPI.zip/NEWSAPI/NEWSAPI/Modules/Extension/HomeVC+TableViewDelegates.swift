//
//  HomeVC+TableViewDelegates.swift
//  NEWSAPI
//
//  Created by VARADA on 06/10/21.
//

import Foundation
import UIKit

extension HomeVC : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return articleList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: NewsTableViewCell.self), for: indexPath) as? NewsTableViewCell else { return NewsTableViewCell() }
        
        let list = articleList[indexPath.row]
        cell.configureCell(list)
        if let image = list.dataImg {
            cell.newsImageView.image = image
            updateDBImageData(list)
        } else {
            cell.newsImageView.image = #imageLiteral(resourceName: "d_default_image")
            self.downloadImage(forItemAtIndex: indexPath.row)
        }
        cell.imgHeightContraint.constant = view.bounds.height * 0.30
        return cell
    }
}


// MARK:- TableView Prefetching DataSource
extension HomeVC: UITableViewDataSourcePrefetching {
    func tableView(_ tableView: UITableView, prefetchRowsAt indexPaths: [IndexPath]) {
        indexPaths.forEach { self.downloadImage(forItemAtIndex: $0.row) }
    }
    
    func tableView(_ tableView: UITableView, cancelPrefetchingForRowsAt indexPaths: [IndexPath]) {
        indexPaths.forEach { self.cancelDownloadingImage(forItemAtIndex: $0.row) }
    }
}


