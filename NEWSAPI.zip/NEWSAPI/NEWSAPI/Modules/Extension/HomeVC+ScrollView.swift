//
//  HomeVC+ScrollView.swift
//  NEWSAPI
//
//  Created by VARADA on 07/10/21.
//

import Foundation
import UIKit

extension HomeVC : UIScrollViewDelegate{
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if scrollView == tableView{
            if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height){
                if Reachability.isConnectedToNetwork(){
                    pageCount+=1
                    callHomeInfoAPI()
                }
            }
        }
    }
}
