//
//  HomeVC+Downloader.swift
//  NEWSAPI
//
//  Created by VARADA on 06/10/21.
//

import Foundation
import UIKit

extension HomeVC{
    // MARK: - Image downloading

     func downloadImage(forItemAtIndex index: Int) {
        
        if let cachedImage = imageCache.object(forKey: NSString(string: articleList[index].urlToImage ?? "")) {
            articleList[index].dataImg = cachedImage
            return
        }
        
        let url = articleList[index].url
        guard tasks.firstIndex(where: { $0.originalRequest?.url == url }) == nil else {
            return
        }
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            DispatchQueue.main.async {
                if let data = data, let image = UIImage(data: data) {
                    self.articleList[index].dataImg = image
                    
                        if let downloadedImage = UIImage(data: data) {
                            self.imageCache.setObject(downloadedImage, forKey: url.absoluteString as NSString)
                        }
                        
                    
                    let indexPath = IndexPath(row: index, section: 0)
                    if self.tableView.indexPathsForVisibleRows?.contains(indexPath) ?? false {
                        self.tableView.reloadRows(at: [IndexPath(row: index, section: 0)], with: .fade)
                    }
                }
            }
        }
        task.resume()
        tasks.append(task)
    }

    func cancelDownloadingImage(forItemAtIndex index: Int) {
        let url = articleList[index].url
        guard let taskIndex = tasks.firstIndex(where: { $0.originalRequest?.url == url }) else {
            return
        }
        let task = tasks[taskIndex]
        task.cancel()
        tasks.remove(at: taskIndex)
    }
}
