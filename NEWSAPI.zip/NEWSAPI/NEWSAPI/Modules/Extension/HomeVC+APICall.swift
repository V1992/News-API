//
//  HomeVC+APICall.swift
//  NEWSAPI
//
//  Created by VARADA on 06/10/21.
//

import Foundation
import UIKit

extension HomeVC{
    func callHomeInfoAPI(){
        let queryItems = [URLQueryItem(name: "q", value: "bitcoin"),
                          URLQueryItem(name: "apiKey", value: Credentials.APIKEY),
                          URLQueryItem(name: "page", value: String(pageCount))]
        var urlComps = URLComponents(string: EndPoint.baseUrl + EndPoint.infoUrl)!
        urlComps.queryItems = queryItems
        let result = urlComps.url!
        let loader = self.loader()
        httpUtility.getApiData(requestUrl: result, resultType: NewsListModel.self) { (status, error, response) in
            
            switch status{
            
                case true :  if let jsonResponse = response {
                                if let articles = jsonResponse.articles{
                                        self.nextArticleList = jsonResponse.articles ?? []
                                    
                                            for (_,article) in articles.enumerated() {
                                                self.articleList.append(article)
                                            }
                                }
                                DispatchQueue.main.async {
                                    self.stopLoader(loader: loader)
                                    self.tableView.reloadData()
                                }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        self.save()
                    }
                            }
                case false : break
            }
        }
    }
}
