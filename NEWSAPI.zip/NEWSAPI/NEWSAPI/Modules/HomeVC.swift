//
//  HomeVC.swift
//  NEWSAPI
//
//  Created by VARADA on 06/10/21.
//

import UIKit
import CoreData

class HomeVC: UIViewController {
    lazy var articleList = [Article]()
    lazy var nextArticleList = [Article]()
    var pageCount = 1
   
    var tasks = [URLSessionTask]()
    let imageCache = NSCache<NSString, UIImage>()

    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "News"
        if Reachability.isConnectedToNetwork(){
            self.deleteAllFromDataBase()
            self.callHomeInfoAPI()
        }else{
            fetchData()
        }
    }
}


extension HomeVC{
    // MARK: Methods to Open, Store and Fetch data
    func openDatabse() -> NSManagedObject{
        let entity = NSEntityDescription.entity(forEntityName: Entity.name, in: context)
        let newArticle = NSManagedObject(entity: entity!, insertInto: context)
        return newArticle
    }
    
    
    func fetchData(){
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: Entity.name)
            request.returnsObjectsAsFaults = false
            do {
                let result = try context.fetch(request)
                for data in result as! [NSManagedObject] {
                    var authorName = ""
                    var newsTitle = ""
                    var newsDesc = ""

                    if let author = data.value(forKey: "author") as? String {
                        authorName = author
                    }
                    if let title = data.value(forKey: "title") as? String {
                        newsTitle = title
                    }
                    if let desc = data.value(forKey: "desc") as? String {
                        newsDesc = desc
                    }
                    var image = UIImage()
                    if let imageData = data.value(forKey: "image") as? Data{
                        if let convertedImage = UIImage(data:imageData) {
                            image = convertedImage
                        }
                    }
                    let loc = Article.init(author: authorName, title: newsTitle, articleDescription: newsDesc, urlToImage: nil, task: nil, dataImg: image, url: nil)
                    self.articleList.append(loc)
                }
            } catch {}
        self.tableView.reloadData()
    }
    
    func save(){
        for (_,data) in self.nextArticleList.enumerated(){
            saveData(data: data, UserDBObj: self.openDatabse())
        }
    }
    
    func saveData(data : Article, UserDBObj:NSManagedObject) {
        UserDBObj.setValue(data.author, forKey: "author")
        UserDBObj.setValue(data.title, forKey: "title")
        UserDBObj.setValue(data.articleDescription, forKey: "desc")
        if let cachedImage = imageCache.object(forKey: NSString(string: data.urlToImage ?? "")) {
            if let dataImg = cachedImage.pngData(){
              UserDBObj.setValue(dataImg, forKey: "image")
            }
        }
        self.saveToDB()
    }
    
    func saveToDB(){
        do {
            try context.save()
        } catch {}
    }
    
    
    func updateDBImageData(_ data: Article) {
        let userDBObj = self.openDatabse()
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: Entity.name)
        fetchRequest.predicate = NSPredicate(format: "title = %@", data.title ?? "")

         let results = try? context.fetch(fetchRequest)
         if results?.count == 0 {} else {
            saveData(data: data, UserDBObj: userDBObj)
         }
    }
    
    func deleteAllFromDataBase(){
        let ReqVar = NSFetchRequest<NSFetchRequestResult>(entityName: Entity.name)
            let DelAllReqVar = NSBatchDeleteRequest(fetchRequest: ReqVar)
        do { try context.execute(DelAllReqVar) }
            catch { print(error) }
    }
}
