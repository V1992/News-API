//
//  NewsListModel.swift
//  NEWSAPI
//
//  Created by VARADA on 06/10/21.
//

import Foundation
import UIKit

// MARK: - NewsListModel
struct NewsListModel: Codable {
    let status: String?
    let totalResults: Int?
    let articles: [Article]?
}

// MARK: - Article
struct Article: Codable {
    let author: String?
    let title: String?
    let articleDescription: String?
    let urlToImage: String?
 
    var task : URLSessionTask?
    var dataImg : UIImage?
    lazy var url: URL = {
        return URL(string: self.urlToImage ?? "")
    }() ?? URL.init(string: EndPoint.baseUrl)!
    
    
    enum CodingKeys: String, CodingKey {
        case author, title
        case articleDescription = "description"
        case urlToImage
    }
}

